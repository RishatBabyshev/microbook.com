-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Янв 18 2013 г., 15:02
-- Версия сервера: 5.1.41
-- Версия PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `microbook`
--

-- --------------------------------------------------------

--
-- Структура таблицы `article_en`
--

CREATE TABLE IF NOT EXISTS `article_en` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `definition` mediumtext NOT NULL,
  `example` mediumtext NOT NULL,
  `task` mediumtext NOT NULL,
  `category_id` int(10) NOT NULL,
  `my_order` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `article_en`
--

INSERT INTO `article_en` (`id`, `name`, `definition`, `example`, `task`, `category_id`, `my_order`) VALUES
(1, 'Simple Program in C++', '<p>This is a simple C++ program. Each C++ program contains function int main() { }. If it is needed user enter library by &ldquo;#include&rdquo; keyword then the name of library. Also in C++ there is a Standard Library. To use its functions we put &ldquo;std::&rdquo; keyword for each function. In future it will show how to make more easy way.<br />Rishat</p>', '<p>#include int main() { std::cout &lt;&lt; "First program"; return 0; } result: First Program</p>', '<p>1. Write a C++ program that prints on screen &ldquo;Second program is coming&rdquo; 2. Write a C++ program that prints on screen &ldquo;Welcome to Kazakhstan&rdquo;</p>', 1, 1),
(2, 'Compile and Execute', '<p>In C++ there are two ways of writing programs with graphical user interface (mostly it is called IDE) or with black screen (mostly it is called command prompt, console, terminal). For second way algorithm is 1 &not; Create a directory (folder), then create a file with cpp extension and open in editor (notepad in Windows). 2 &ndash; Write C++ code. (Also can be copied) 3 &ndash; Open command prompt (in Windows run Windows sign + R then write cmd) 4 &ndash; Go to needed folder by using command cd. 5 &ndash; In command prompt write &ldquo;g++ name_of_file.cpp&rdquo; and press Enter 6 &ndash; If no error appears name_of_file.exe or a.exe must appear. 7 &ndash; Write this file and press Enter</p>', '<p>#include int main() { std::cout &lt;&lt; "Second program"; return 0; } Resukt: Second Program</p>', '<p>1. Write a C++ program with output &ldquo;Hello&rdquo;</p>', 1, 2),
(3, 'Arithmetic operators', 'There are 5 standard arithmetic operators in C++.\r\nOperation			Arithmetic operator\r\nAddition					+\r\nSubtraction					- \r\nMultiplication				*\r\nDivision					/\r\nModulus					%\r\n', '// Calculator\r\n\r\n#include <iostream>\r\n\r\nint main()\r\n{\r\nint x, y;\r\nstd::cout << "Enter two numbers : ";\r\nstd::cin >> x >> y;\r\nstd::cout << "Sum : " << x + y; 	\r\nreturn 0;\r\n}				\r\n\r\n\r\nTry 1:\r\nEnter two numbers : 1 5\r\nSum : 6\r\nTry 2:\r\nEnter two numbers : 2 3\r\nSum : 5\r\n', '1. Make a calculator program for 5 operations', 2, 1),
(4, 'Comments', '<p class="D1"><span lang="EN-US">In C++ there are 2 types of comments</span></p>\r\n<p class="D1"><span lang="EN-US">1 &ndash; single line comment &not; //</span></p>\r\n<p class="D1"><span lang="EN-US">2 &ndash; multiline comment &not; /* ...</span></p>\r\n<p class="D1"><span lang="EN-US">&hellip;......</span></p>\r\n<p class="D1"><span lang="EN-US">&hellip;. */</span></p>\r\n<p class="D1"><span lang="EN-US">Mostly new programmers do not use comments in their programs. But after more practice and time they understand that it is important.&nbsp; Because humans have ability to forget.</span></p>', '<table border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top" width="36">\r\n<p class="C1">&nbsp;</p>\r\n</td>\r\n<td valign="top" width="390">\r\n<p class="C1">C++ CODE</p>\r\n</td>\r\n<td valign="top" width="213">\r\n<p class="C1">RESULT</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="36">\r\n<p class="C1">1</p>\r\n<p class="C1">2</p>\r\n<p class="C1">3</p>\r\n<p class="C1">4</p>\r\n<p class="C1">5</p>\r\n<p class="C1">6</p>\r\n<p class="C1">7</p>\r\n<p class="C1">8</p>\r\n<p class="C1">9</p>\r\n<p class="C1">10</p>\r\n<p class="C1">11</p>\r\n<p class="C1">12</p>\r\n<p class="C1">13</p>\r\n<p class="C1">14</p>\r\n<p class="C1">15</p>\r\n<p class="C1">16</p>\r\n<p class="C1">17</p>\r\n<p class="C1">18</p>\r\n</td>\r\n<td valign="top" width="390">\r\n<p class="C1">// Comments in C++ &nbsp;</p>\r\n<p class="C1">#include</p>\r\n<p class="C1">&nbsp;</p>\r\n<p class="C1">int main()</p>\r\n<p class="C1">{</p>\r\n<p class="C1">int i; // single-line comment</p>\r\n<p class="C1">/* Read the number</p>\r\n<p class="C1">to be tested whether odd or even</p>\r\n<p class="C1">*/</p>\r\n<p class="C1">std::cout &lt;&lt; "Enter an integer : ";</p>\r\n<p class="C1">std::cin &gt;&gt; i;</p>\r\n<p class="C1">// check if number i is even or odd &nbsp;&nbsp;</p>\r\n<p class="C1">if ((i%2)==0)</p>\r\n<p class="C1">std::cout &lt;&lt; i &lt;&lt;" is even";</p>\r\n<p class="C1">else</p>\r\n<p class="C1">std::cout &lt;&lt; i &lt;&lt;" is odd";</p>\r\n<p class="C1">return 0;</p>\r\n<p class="C1">}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p class="C1">&nbsp;</p>\r\n</td>\r\n<td valign="top" width="213">\r\n<p class="C1">Try 1:</p>\r\n<p class="C1">Enter an integer : 5</p>\r\n<p class="C1">5 is odd</p>\r\n<p class="C1">&nbsp;</p>\r\n<p class="C1">Try 2:</p>\r\n<p class="C1">Enter an integer : 6</p>\r\n<p class="C1">6 is even</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', '<p class="D1">1. Write a C++ program with comments that checks if number is divisible by 3.</p>\r\n<p class="D1">2. Write a C++ program of adding two float numbers with comments.</p>\r\n<p class="D1">3. Write a C++ program with comments that checks if number is positive or negative.</p>\r\n<p>&nbsp;</p>', 1, 3),
(6, 'test2', '<p>werf</p>', '<p>werf</p>', '<p>werf</p>', 2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `article_kz`
--

CREATE TABLE IF NOT EXISTS `article_kz` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `definition` mediumtext NOT NULL,
  `example` mediumtext NOT NULL,
  `task` mediumtext NOT NULL,
  `category_id` int(10) NOT NULL,
  `my_order` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `article_kz`
--

INSERT INTO `article_kz` (`id`, `name`, `definition`, `example`, `task`, `category_id`, `my_order`) VALUES
(1, 'Simple Program in C++', 'This is a simple C++ program. Each C++ program contains function int main() { }. If it is needed user enter library by “#include” keyword then the name of library. Also in C++ there is a Standard Library. To use its functions we put “std::” keyword for each function. In future it will show how to make more easy way.', '#include <iostream>\r\n\r\nint main()\r\n{\r\nstd::cout << "First program";\r\nreturn 0;\r\n}\r\n\r\nresult: First Program', '1. Write a C++ program that prints on screen “Second program is coming”\r\n2. Write a C++ program that prints on screen “Welcome to Kazakhstan”', 1, 1),
(2, 'Compile and Execute', 'In C++ there are two ways of writing programs with graphical user interface (mostly it is called IDE) or with black screen (mostly it is called command prompt, console, terminal). For second way algorithm is\r\n1 ¬ Create a directory (folder), then create a file with cpp extension and open in editor (notepad in Windows).\r\n2 – Write C++ code. (Also can be copied)\r\n3 – Open command prompt (in Windows run Windows sign + R then write cmd)\r\n4 – Go to needed folder by using command cd.\r\n5 – In command prompt write “g++ name_of_file.cpp” and press Enter\r\n6 – If no error appears name_of_file.exe or a.exe must appear.\r\n7 – Write this file and press Enter\r\n', '#include <iostream>\r\n\r\nint main()\r\n{\r\nstd::cout << "Second program";\r\nreturn 0;\r\n}\r\n\r\nResukt: Second Program', '1. Write a C++ program with output “Hello”', 1, 2),
(3, 'Arithmetic operators', 'There are 5 standard arithmetic operators in C++.\r\nOperation			Arithmetic operator\r\nAddition					+\r\nSubtraction					- \r\nMultiplication				*\r\nDivision					/\r\nModulus					%\r\n', '// Calculator\r\n\r\n#include <iostream>\r\n\r\nint main()\r\n{\r\nint x, y;\r\nstd::cout << "Enter two numbers : ";\r\nstd::cin >> x >> y;\r\nstd::cout << "Sum : " << x + y; 	\r\nreturn 0;\r\n}				\r\n\r\n\r\nTry 1:\r\nEnter two numbers : 1 5\r\nSum : 6\r\nTry 2:\r\nEnter two numbers : 2 3\r\nSum : 5\r\n', '1. Make a calculator program for 5 operations', 2, 1),
(4, 'Comments', '<p class="D1"><span lang="EN-US">In C++ there are 2 types of comments</span></p>\r\n<p class="D1"><span lang="EN-US">1 &ndash; single line comment &not; //</span></p>\r\n<p class="D1"><span lang="EN-US">2 &ndash; multiline comment &not; /* ...</span></p>\r\n<p class="D1"><span lang="EN-US">&hellip;......</span></p>\r\n<p class="D1"><span lang="EN-US">&hellip;. */</span></p>\r\n<p class="D1"><span lang="EN-US">Mostly new programmers do not use comments in their programs. But after more practice and time they understand that it is important.&nbsp; Because humans have ability to forget.</span></p>', '<table border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top" width="36">\r\n<p class="C1">&nbsp;</p>\r\n</td>\r\n<td valign="top" width="390">\r\n<p class="C1">C++ CODE</p>\r\n</td>\r\n<td valign="top" width="213">\r\n<p class="C1">RESULT</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="36">\r\n<p class="C1">1</p>\r\n<p class="C1">2</p>\r\n<p class="C1">3</p>\r\n<p class="C1">4</p>\r\n<p class="C1">5</p>\r\n<p class="C1">6</p>\r\n<p class="C1">7</p>\r\n<p class="C1">8</p>\r\n<p class="C1">9</p>\r\n<p class="C1">10</p>\r\n<p class="C1">11</p>\r\n<p class="C1">12</p>\r\n<p class="C1">13</p>\r\n<p class="C1">14</p>\r\n<p class="C1">15</p>\r\n<p class="C1">16</p>\r\n<p class="C1">17</p>\r\n<p class="C1">18</p>\r\n</td>\r\n<td valign="top" width="390">\r\n<p class="C1">// Comments in C++ &nbsp;</p>\r\n<p class="C1">#include &lt;iostream&gt;</p>\r\n<p class="C1">&nbsp;</p>\r\n<p class="C1">int main()</p>\r\n<p class="C1">{</p>\r\n<p class="C1">int i; // single-line comment</p>\r\n<p class="C1">/* Read the number</p>\r\n<p class="C1">to be tested whether odd or even</p>\r\n<p class="C1">*/</p>\r\n<p class="C1">std::cout &lt;&lt; "Enter an integer : ";</p>\r\n<p class="C1">std::cin &gt;&gt; i;</p>\r\n<p class="C1">// check if number i is even or odd &nbsp;&nbsp;</p>\r\n<p class="C1">if ((i%2)==0)</p>\r\n<p class="C1">std::cout &lt;&lt; i &lt;&lt;" is even";</p>\r\n<p class="C1">else</p>\r\n<p class="C1">std::cout &lt;&lt; i &lt;&lt;" is odd";</p>\r\n<p class="C1">return 0;</p>\r\n<p class="C1">}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p class="C1">&nbsp;</p>\r\n</td>\r\n<td valign="top" width="213">\r\n<p class="C1">Try 1:</p>\r\n<p class="C1">Enter an integer : 5</p>\r\n<p class="C1">5 is odd</p>\r\n<p class="C1">&nbsp;</p>\r\n<p class="C1">Try 2:</p>\r\n<p class="C1">Enter an integer : 6</p>\r\n<p class="C1">6 is even</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', '<p class="D1">1. Write a C++ program with comments that checks if number is divisible by 3.</p>\r\n<p class="D1">2. Write a C++ program of adding two float numbers with comments.</p>\r\n<p class="D1">3. Write a C++ program with comments that checks if number is positive or negative.</p>\r\n<p>&nbsp;</p>', 1, 3),
(6, 'test2', '<p>werf</p>', '<p>werf</p>', '<p>werf</p>', 2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `article_ru`
--

CREATE TABLE IF NOT EXISTS `article_ru` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `definition` mediumtext NOT NULL,
  `example` mediumtext NOT NULL,
  `task` mediumtext NOT NULL,
  `category_id` int(10) NOT NULL,
  `my_order` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `article_ru`
--

INSERT INTO `article_ru` (`id`, `name`, `definition`, `example`, `task`, `category_id`, `my_order`) VALUES
(1, 'Simple Program in C++', '<p>This is a simple C++ program. Each C++ program contains function int main() { }. If it is needed user enter library by &ldquo;#include&rdquo; keyword then the name of library. Also in C++ there is a Standard Library. To use its functions we put &ldquo;std::&rdquo; keyword for each function. In future it will show how to make more easy way. Вот так</p>', '<p>#include int main() { std::cout &lt;&lt; "First program"; return 0; } result: First Program</p>', '<p>1. Write a C++ program that prints on screen &ldquo;Second program is coming&rdquo; 2. Write a C++ program that prints on screen &ldquo;Welcome to Kazakhstan&rdquo;</p>', 1, 1),
(2, 'Compile and Execute', 'In C++ there are two ways of writing programs with graphical user interface (mostly it is called IDE) or with black screen (mostly it is called command prompt, console, terminal). For second way algorithm is\r\n1 ¬ Create a directory (folder), then create a file with cpp extension and open in editor (notepad in Windows).\r\n2 – Write C++ code. (Also can be copied)\r\n3 – Open command prompt (in Windows run Windows sign + R then write cmd)\r\n4 – Go to needed folder by using command cd.\r\n5 – In command prompt write “g++ name_of_file.cpp” and press Enter\r\n6 – If no error appears name_of_file.exe or a.exe must appear.\r\n7 – Write this file and press Enter\r\n', '#include <iostream>\r\n\r\nint main()\r\n{\r\nstd::cout << "Second program";\r\nreturn 0;\r\n}\r\n\r\nResukt: Second Program', '1. Write a C++ program with output “Hello”', 1, 2),
(3, 'Arithmetic operators', 'There are 5 standard arithmetic operators in C++.\r\nOperation			Arithmetic operator\r\nAddition					+\r\nSubtraction					- \r\nMultiplication				*\r\nDivision					/\r\nModulus					%\r\n', '// Calculator\r\n\r\n#include <iostream>\r\n\r\nint main()\r\n{\r\nint x, y;\r\nstd::cout << "Enter two numbers : ";\r\nstd::cin >> x >> y;\r\nstd::cout << "Sum : " << x + y; 	\r\nreturn 0;\r\n}				\r\n\r\n\r\nTry 1:\r\nEnter two numbers : 1 5\r\nSum : 6\r\nTry 2:\r\nEnter two numbers : 2 3\r\nSum : 5\r\n', '1. Make a calculator program for 5 operations', 2, 1),
(4, 'Comments', '<p class="D1"><span lang="EN-US">In C++ there are 2 types of comments</span></p>\r\n<p class="D1"><span lang="EN-US">1 &ndash; single line comment &not; //</span></p>\r\n<p class="D1"><span lang="EN-US">2 &ndash; multiline comment &not; /* ...</span></p>\r\n<p class="D1"><span lang="EN-US">&hellip;......</span></p>\r\n<p class="D1"><span lang="EN-US">&hellip;. */</span></p>\r\n<p class="D1"><span lang="EN-US">Mostly new programmers do not use comments in their programs. But after more practice and time they understand that it is important.&nbsp; Because humans have ability to forget.</span></p>', '<table border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top" width="36">\r\n<p class="C1">&nbsp;</p>\r\n</td>\r\n<td valign="top" width="390">\r\n<p class="C1">C++ CODE</p>\r\n</td>\r\n<td valign="top" width="213">\r\n<p class="C1">RESULT</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="36">\r\n<p class="C1">1</p>\r\n<p class="C1">2</p>\r\n<p class="C1">3</p>\r\n<p class="C1">4</p>\r\n<p class="C1">5</p>\r\n<p class="C1">6</p>\r\n<p class="C1">7</p>\r\n<p class="C1">8</p>\r\n<p class="C1">9</p>\r\n<p class="C1">10</p>\r\n<p class="C1">11</p>\r\n<p class="C1">12</p>\r\n<p class="C1">13</p>\r\n<p class="C1">14</p>\r\n<p class="C1">15</p>\r\n<p class="C1">16</p>\r\n<p class="C1">17</p>\r\n<p class="C1">18</p>\r\n</td>\r\n<td valign="top" width="390">\r\n<p class="C1">// Comments in C++ &nbsp;</p>\r\n<p class="C1">#include</p>\r\n<p class="C1">&nbsp;</p>\r\n<p class="C1">int main()</p>\r\n<p class="C1">{</p>\r\n<p class="C1">int i; // single-line comment</p>\r\n<p class="C1">/* Read the number</p>\r\n<p class="C1">to be tested whether odd or even</p>\r\n<p class="C1">*/</p>\r\n<p class="C1">std::cout &lt;&lt; "Enter an integer : ";</p>\r\n<p class="C1">std::cin &gt;&gt; i;</p>\r\n<p class="C1">// check if number i is even or odd &nbsp;&nbsp;</p>\r\n<p class="C1">if ((i%2)==0)</p>\r\n<p class="C1">std::cout &lt;&lt; i &lt;&lt;" is even";</p>\r\n<p class="C1">else</p>\r\n<p class="C1">std::cout &lt;&lt; i &lt;&lt;" is odd";</p>\r\n<p class="C1">return 0;</p>\r\n<p class="C1">}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p class="C1">&nbsp;</p>\r\n</td>\r\n<td valign="top" width="213">\r\n<p class="C1">Try 1:</p>\r\n<p class="C1">Enter an integer : 5</p>\r\n<p class="C1">5 is odd</p>\r\n<p class="C1">&nbsp;</p>\r\n<p class="C1">Try 2:</p>\r\n<p class="C1">Enter an integer : 6</p>\r\n<p class="C1">6 is even</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', '<p class="D1">1. Write a C++ program with comments that checks if number is divisible by 3.</p>\r\n<p class="D1">2. Write a C++ program of adding two float numbers with comments.</p>\r\n<p class="D1">3. Write a C++ program with comments that checks if number is positive or negative.</p>\r\n<p>&nbsp;</p>', 1, 3),
(6, 'test2', '<p>werf</p>', '<p>werf</p>', '<p>werf</p>', 2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(300) NOT NULL,
  `name_ru` varchar(300) NOT NULL,
  `name_kz` varchar(300) NOT NULL,
  `my_order` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`id`, `name_en`, `name_ru`, `name_kz`, `my_order`) VALUES
(1, 'first look to C++', 'Первый взгляд на  C++', 'first look to C++', 1),
(2, 'USING OPERATORS', 'Операторы', 'USING OPERATORS', 2),
(3, 'COMPARE', 'Сравнение', 'COMPARE', 3),
(6, 'POINTER', 'Поинтеры', 'Поинтерлер', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `offline` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `offline`) VALUES
(1, 'Welcome to C++', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `login` varchar(200) NOT NULL,
  `password` varchar(300) NOT NULL,
  `role_id` int(10) NOT NULL,
  `email` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `role_id`, `email`) VALUES
(1, 'admin', 'admin', 1, 'admin@admin.com'),
(2, 'Rishat', '1', 1, 'b.rishat@gmail.com');

-- --------------------------------------------------------

--
-- Структура таблицы `u_privilege`
--

CREATE TABLE IF NOT EXISTS `u_privilege` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Дамп данных таблицы `u_privilege`
--

INSERT INTO `u_privilege` (`id`, `name`) VALUES
(1, 'CREATE_USER'),
(2, 'EDIT_USER'),
(3, 'DELETE_USER'),
(4, 'CREATE_ARTICLE'),
(5, 'EDIT_ARTICLE'),
(6, 'DELETE_ARTICLE'),
(7, 'ADD_CATEGORY'),
(8, 'EDIT_CATEGORY'),
(9, 'DELETE_CATEGORY'),
(10, 'ADD_ROLE'),
(11, 'EDIT_ROLE'),
(12, 'DELETE_ROLE'),
(13, 'ADD_PRIVELEGE'),
(14, 'EDIT_PRIVELEGE'),
(15, 'DELETE_PRIVELEGE'),
(16, 'EDIT_GLOBAL_SETTINGS');

-- --------------------------------------------------------

--
-- Структура таблицы `u_role`
--

CREATE TABLE IF NOT EXISTS `u_role` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `u_role`
--

INSERT INTO `u_role` (`id`, `name`) VALUES
(1, 'admin'),
(2, 'manager');

-- --------------------------------------------------------

--
-- Структура таблицы `u_role_privilege`
--

CREATE TABLE IF NOT EXISTS `u_role_privilege` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `role_id` int(10) NOT NULL,
  `privilege_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Дамп данных таблицы `u_role_privilege`
--

INSERT INTO `u_role_privilege` (`id`, `role_id`, `privilege_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 1, 12),
(13, 1, 13),
(14, 1, 14),
(15, 1, 15),
(16, 1, 16),
(17, 2, 4),
(18, 2, 5),
(19, 2, 6);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
