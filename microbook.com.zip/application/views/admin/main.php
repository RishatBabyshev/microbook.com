﻿  
    <div class="submenu">
    <ul>
    <li><a href="<?php echo site_url('admin/main');?>" class="selected">main page</a></li>
    </ul>
    </div>          
                    
    <div class="center_content">  
 
    <div id="right_wrap">
		<div id="right_content">             
			<h2>Quick icons</h2>
			<br />
			<div class="cpanel">
				<div class="icon-wrapper">
					<div class="icon">
						<a href="<?php echo site_url('admin/article_add');?>">
							<img src="<?php echo base_url();?>images/quick-icon/article-add.png" alt="">
							<span>Add New Article</span>
						</a>
					</div>
				</div>
				<div class="icon-wrapper">
					<div class="icon">
						<a href="<?php echo site_url('admin/article_list');?>">
							<img src="<?php echo base_url();?>images/quick-icon/article-list.png" alt="">
							<span>Article Manager</span>
						</a>
					</div>
				</div>
				<div class="icon-wrapper">
					<div class="icon">
						<a href="<?php echo site_url('admin/category_list');?>">
							<img src="<?php echo base_url();?>images/quick-icon/category-list.png" alt="">
							<span>Category Manager</span>
						</a>
					</div>
				</div>
				<div class="icon-wrapper">
					<div class="icon">
						<a href="#">
							<img src="<?php echo base_url();?>images/quick-icon/user.png" alt="">
							<span>User Manager</span>
						</a>
					</div>
				</div>
				<div class="icon-wrapper">
					<div class="icon">
						<a href="<?php echo site_url('admin/settings');?>">
							<img src="<?php echo base_url();?>images/quick-icon/config.png" alt="">
							<span>Settings</span>
						</a>
					</div>
				</div>
				<div class="icon-wrapper">
					<div class="icon">
						<a href="#">
							<img src="<?php echo base_url();?>images/quick-icon/help.png" alt="">
							<span>Help</span>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div><!-- end of right content-->
                     
                    
    
    
    <div class="clear"></div>
    </div> <!--end of center_content-->
    
    <div class="footer">
	</div>

</div>

    	
</body>
</html>