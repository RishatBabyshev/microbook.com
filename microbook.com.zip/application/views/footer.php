		</tr>
	</table>
	</div>
	<div id="footer">
		<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds</p>
	</div>
	
</div>
</body>

</html>